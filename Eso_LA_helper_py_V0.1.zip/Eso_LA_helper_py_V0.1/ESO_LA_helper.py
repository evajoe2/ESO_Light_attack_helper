"""
    this is  the Elder Scroll online light attack helper
    when you use the assigned skill key , also have light attack enabled
    you can run on any python ide , or windows cmd after you install python 3.10
    you need pip install pynput
    this program is Ver 0.1 and tested on python 3.10
    
"""
import csv
import pynput
from pynput.keyboard import Key, Listener,Controller as key_cl
from pynput.mouse import Button, Controller
import time
import random

with open('keymap.csv') as fr:
    km_r = csv.reader(fr,delimiter=',')
    for row in km_r:
        d_k1,d_k2,d_k3,d_k4,d_k5 = (row)
        print ("Now the key setting are \n skill 1 = " + d_k1 + ", skill 2 = " + d_k2 + ", skill 3 = " + d_k3 +', skill 4 = ' + d_k4 +', skill 5 = '+d_k5)
    
    
d_time =0.08 # delay time for light attack and skill
keyboard = key_cl()
mouse = Controller()
#d_k1 = str(6)
#d_k2 = str(7)
#d_k3 = str(8)
#d_k4 = str(9)
#d_k5 = str(0)
#print ("Now the key setting are \n skill 1 = " + d_k1 + ", skill 2 = " + d_k2 + ", skill 3 = " + d_k3 +', skill 4 = ' + d_k4 +', skill 5 = '+d_k5)
Remapkey = input("do you want to re-map keys ? y or n: \n")
if Remapkey == 'y':
    d_k1 = input ("skill 1 = ?  ")
    d_k2 = input ("skill 2 = ?  ")
    d_k3 = input ("skill 3 = ?  ")
    d_k4 = input ("skill 4 = ?  ")
    d_k5 = input ("skill 5 = ?  ")
    
    print ("New key setting are \n skill 1 = " + d_k1 + ", skill 2 = " + d_k2 + ", skill 3 = " + d_k3 +', skill 4 = ' + d_k4 +', skill 5 = '+d_k5 )
    with open('keymap.csv', 'w',newline='') as fw:
        dwriter = csv.writer(fw)
        dwriter.writerow([d_k1,d_k2,d_k3,d_k4,d_k5])
else:
    print()   
    

print ("press home key to exit program")


def on_press(key):
    #print('{0} pressed'.format(key))
    if (key.char if hasattr(key, 'char') else key.name) == d_k1: 
        # '6' is the key you press, you can assign what you want
        print('use skill 1') #skill 1  
        mouse.press(Button.left)
        time.sleep(round(d_time*(random.uniform(0.8,1.1)),2))
        mouse.release(Button.left)
        keyboard.press('1') # key 1 is you assign on game console, you can assign in game settings
        keyboard.release('1')  
        
         
    
    if (key.char if hasattr(key, 'char') else key.name) == d_k2:
        print('use skill 2')
        mouse.press(Button.left)
        time.sleep (round(d_time*(random.uniform(0.8,1.1)),2))
        mouse.release(Button.left)
        keyboard.press('2')
        keyboard.release('2')  
         
        
        
    if (key.char if hasattr(key, 'char') else key.name) == d_k3:
        print('use skill 3')
        mouse.press(Button.left)
        time.sleep (round(d_time*(random.uniform(0.8,1.1)),2))
        mouse.release(Button.left)
        keyboard.press('3')
        keyboard.release('3')  
         
    
    if (key.char if hasattr(key, 'char') else key.name) == d_k4:
        print('use skill 4')
        mouse.press(Button.left)
        time.sleep (round(d_time*(random.uniform(0.8,1.1)),2))
        mouse.release(Button.left)
        keyboard.press('4')
        keyboard.release('4')  
         
    
    if (key.char if hasattr(key, 'char') else key.name) == d_k5:
        print('use skill 5')
        mouse.press(Button.left)
        time.sleep (round(d_time*(random.uniform(0.8,1.1)),2))
        mouse.release(Button.left)
        keyboard.press('5')
        keyboard.release('5')  
         
    
    
    
    if key == Key.home:
        # Stop listener
        return False
def on_release(key):
    #print('{0} release'.format(key))
    """if key == Key.esc:
        # Stop listener
        return False
"""

with Listener(
        on_press=on_press,
        on_release=on_release) as listener:
    listener.join()